# -*- coding: utf-8 -*-
from distutils.core import setup
from setuptools import find_packages


setup(
    name='django-login',
    version='0.2',
    author=u'Edouard Richard',
    author_email='edou4rd@gmail.com',
    url='',
    license='',
    description='Login page',
    zip_safe=False,
    packages=find_packages(),
    include_package_data=True,
)



